#define ORB_HEIGHT_YELLOW_UPSIDE2 (-0x580) // unused


#define GRAVITY_DOWN 0x00
#define GRAVITY_UP 0xFF
#define invert_gravity(var) (var ^= 0xFF)