
// Exported by export_levels.py

const uint8_t difficulty_list[] = {
	MEDIUMDEMON,	// goldenhaze
	HARDDEMON,	// demoncryogenic
	HARDDEMON,	// foresttemple
	EXTREMEDEMON,	// windylandscape
	IMPOSSIBLEDEMON,	// silentclubstep
	IMPOSSIBLEDEMON,	// aftercatabath
	IMPOSSIBLEDEMON,	// shardscapes
	IMPOSSIBLEDEMON,	// element111rg_with_secret_way
	GRANDPADEMON,	// slaughterhouse
	GRANDPADEMON,	// kratos
};

const uint8_t stars_list[] = {
	10,	// goldenhaze
	10,	// demoncryogenic
	10,	// foresttemple
	10,	// windylandscape
	10,	// silentclubstep
	10,	// aftercatabath
	10,	// shardscapes
	10,	// element111rg_with_secret_way
	10,	// slaughterhouse
	10,	// kratos
};
