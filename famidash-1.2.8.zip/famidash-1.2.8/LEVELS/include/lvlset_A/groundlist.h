// GROUND ORDERING ============================================
//
// NOTE: DO *NOT* PUT GROUND DATA HERE.
// this is where the ground order is defined.
//
// ============================================================
//
// You can generate ground data [INSTRUCTIONS REMOVED, DO IT MANUALLY MOTHERFCERS]
//
// Put the contents of the file in grounddata.h, and then put
// the name of the ground in the pointer list below.
//
// ============================================================

const unsigned char * const ground[] = {ground0};