
// Exported by export_levels.py

const uint8_t difficulty_list[] = {
};

const uint8_t stars_list[] = {
};
