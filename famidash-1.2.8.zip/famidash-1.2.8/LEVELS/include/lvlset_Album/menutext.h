
// Exported by export_levels.py



const char* const levelTextsUpper[] = {
};

const uint8_t levelTextsUpperSize[] = {
};


const char* const levelTextsLower[] = {
};

const uint8_t levelTextsLowerSize[] = {
};
