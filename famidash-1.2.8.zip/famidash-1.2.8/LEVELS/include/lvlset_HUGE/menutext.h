
// Exported by export_levels.py

const char levelText00[ 7] = "STEREO ";
const char levelText01[ 7] = "BACK ON";
const char levelText02[10] = "BASE AFTER";
const char levelText03[ 9] = "THEORY OF";
const char levelText04[10] = "ELECTROMAN";
const char levelText05[ 7] = "HEXAGON";
const char levelText06[ 5] = "BLAST";
const char levelText07[11] = "GEOMETRICAL";
const char levelText08[ 3] = "THE";
const char levelText09[ 7] = "DORABAE";
const char levelText0A[ 7] = "LOOK AT";
const char levelText0B[ 9] = "GROUND TO";
const char levelText0C[ 7] = "ULTIATE";
const char levelText0D[ 5] = "FOFII";
const char levelText0E[ 6] = "SELECT";
const char levelText0F[10] = "GENERATION";
const char levelText10[ 7] = "SCARLET";
const char levelText11[ 9] = "FUNNYGAME";
const char levelText12[ 7] = "RAINBOW";
const char levelText13[ 7] = "LOST IN";
const char levelText14[ 9] = "BLOODBATH";
const char levelText15[12] = "DORABAEBASIC";
const char levelText16[ 6] = "SUBTLE";
const char levelText17[ 8] = "DANCE OF";
const char levelText18[10] = "YOUVE BEEN";
const char levelText19[ 8] = "A PRETTY";
const char levelText1A[13] = "EXTRAORDINARY";
const char levelText1B[13] = "THE LIGHTNING";
const char levelText1C[ 8] = "INFINITE";
const char levelText1D[ 5] = "SONIC";
const char levelText1E[ 9] = "ENDORPHIN";
const char levelText1F[ 5] = "EVERY";
const char levelText20[ 8] = "SKELETAL";
const char levelText21[ 9] = "INVISIBLE";
const char levelText22[ 6] = "DEADLY";
const char levelText23[ 5] = "WINDY";
const char levelText24[ 6] = "SILENT";
const char levelText25[ 7] = "ELEMENT";
const char levelText26[ 7] = "MADNESS";
const char levelText27[ 5] = "TRACK";
const char levelText28[10] = "POLARGEIST";
const char levelText29[ 7] = "DRY OUT";
const char levelText2A[ 4] = "BASE";
const char levelText2B[11] = "CANT LET GO";
const char levelText2C[ 6] = "JUMPER";
const char levelText2D[12] = "TIME MACHINE";
const char levelText2E[ 6] = "CYCLES";
const char levelText2F[ 5] = "XSTEP";
const char levelText30[11] = "CLUTTERFUNK";
const char levelText31[10] = "EVERYTHING";
const char levelText32[10] = "ADVENTURES";
const char levelText33[ 8] = "CLUBSTEP";
const char levelText34[15] = " ELECTRODYNAMIX";
const char levelText35[ 5] = "FORCE";
const char levelText36[10] = "PROCESSING";
const char levelText37[12] = "EVERYTHING 2";
const char levelText38[ 9] = "DOMINATOR";
const char levelText39[10] = "DEADLOCKED";
const char levelText3A[10] = "FINGERDASH";
const char levelText3B[ 4] = "DASH";
const char levelText3C[ 6] = "RETRAY";
const char levelText3D[ 5] = "SONAR";
const char levelText3E[13] = "DARK PARADISE";
const char levelText3F[10] = "LEVEL EASY";
const char levelText40[ 9] = "CHALLENGE";
const char levelText41[ 6] = "BASIC4";
const char levelText42[ 5] = "NINOX";
const char levelText43[ 6] = "BASIC6";
const char levelText44[ 7] = "DREAMER";
const char levelText45[10] = "THIS LEVEL";
const char levelText46[ 5] = "SPACE";
const char levelText47[11] = "DESTRUCTION";
const char levelText48[ 7] = "SUBZERO";
const char levelText49[ 9] = "MOONLIGHT";
const char levelText4A[11] = "FOFII FOFII";
const char levelText4B[12] = "PAYMENT TYPE";
const char levelText4C[10] = "PYROPHORIC";
const char levelText4D[ 9] = "CRYOGENIC";
const char levelText4E[ 6] = "OCEANE";
const char levelText4F[ 5] = "RETRO";
const char levelText50[ 5] = "SURGE";
const char levelText51[10] = "TINY TUNES";
const char levelText52[10] = "KAPPACLYSM";
const char levelText53[ 8] = "SUNSHINE";
const char levelText54[10] = "REVOLUTION";
const char levelText55[ 7] = "HOLIDAY";
const char levelText56[ 9] = "FIRE AURA";
const char levelText57[ 4] = "DUST";
const char levelText58[12] = "FACTORY TIME";
const char levelText59[14] = "THE STEAMWORKS";
const char levelText5A[ 9] = "THE WOODS";
const char levelText5B[13] = "RAINING TACOS";
const char levelText5C[ 6] = "BUT NO";
const char levelText5D[ 7] = "TYLENOL";
const char levelText5E[ 5] = "GREIF";
const char levelText5F[ 2] = "10";
const char levelText60[ 8] = "ODDITIES";
const char levelText61[10] = "POWER TRIP";
const char levelText62[ 7] = "VIOLINS";
const char levelText63[ 7] = "TROLLED";
const char levelText64[10] = "EASY LEVEL";
const char levelText65[ 9] = "HIGH LIFE";
const char levelText66[10] = "EXCITEMENT";
const char levelText67[ 4] = "ROAD";
const char levelText68[13] = "THE NIGHTMARE";
const char levelText69[10] = "DEMON PARK";
const char levelText6A[12] = "SUPER CYCLES";
const char levelText6B[ 1] = "X";
const char levelText6C[11] = "PROBLEMATIC";
const char levelText6D[ 7] = "CIRCLES";
const char levelText6E[ 7] = "BLASTER";
const char levelText6F[ 6] = "DECODE";
const char levelText70[10] = "DEATH MOON";
const char levelText71[13] = "CLUTTERFUNK 2";
const char levelText72[ 6] = "MOTION";
const char levelText73[11] = "SPEED RACER";
const char levelText74[ 4] = "RUSH";
const char levelText75[11] = "SHENANIGANS";
const char levelText76[11] = "TRY THIS GD";
const char levelText77[11] = "GOLDEN HAZE";
const char levelText78[ 4] = "HELL";
const char levelText79[ 5] = "LIGHT";
const char levelText7A[11] = "FIRE TEMPLE";
const char levelText7B[11] = "PG CLUBSTEP";
const char levelText7C[13] = "THERMODYNAMIX";
const char levelText7D[15] = "DEMON CRYOGENIC";
const char levelText7E[13] = "FOREST TEMPLE";
const char levelText7F[12] = "NINE CIRCLES";
const char levelText80[ 9] = "FAIRYDUST";
const char levelText81[ 9] = "STALEMATE";
const char levelText82[ 2] = "8O";
const char levelText83[ 2] = "HI";
const char levelText84[ 3] = "EON";
const char levelText85[ 9] = "LANDSCAPE";
const char levelText86[10] = "SONIC WAVE";
const char levelText87[ 9] = "CATACLYSM";
const char levelText88[ 9] = "AFTERMATH";
const char levelText89[13] = "AFTERCATABATH";
const char levelText8A[11] = "SHARDSCAPES";
const char levelText8B[ 6] = "111 RG";
const char levelText8C[14] = "SLAUGHTERHOUSE";
const char levelText8D[ 6] = "KRATOS";
const char levelText8E[ 9] = "EVERY END";
const char levelText8F[10] = "LUCKY DRAW";


const char* const levelTextsUpper[] = {
	levelText00,
	levelText01,
	NULL,
	NULL,
	levelText02,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText03,
	levelText04,
	NULL,
	NULL,
	levelText05,
	levelText06,
	levelText03,
	levelText07,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText08,
	levelText09,
	NULL,
	levelText09,
	NULL,
	levelText0A,
	levelText0B,
	levelText0C,
	NULL,
	NULL,
	levelText0D,
	levelText0E,
	NULL,
	NULL,
	NULL,
	levelText0F,
	levelText10,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText11,
	NULL,
	levelText12,
	NULL,
	NULL,
	levelText13,
	NULL,
	levelText14,
	levelText12,
	NULL,
	levelText15,
	levelText16,
	NULL,
	levelText17,
	levelText18,
	levelText19,
	NULL,
	levelText1A,
	levelText1B,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText1C,
	levelText1D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText1E,
	levelText1F,
	levelText20,
	NULL,
	NULL,
	NULL,
	levelText21,
	NULL,
	NULL,
	levelText22,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText23,
	NULL,
	NULL,
	NULL,
	NULL,
	levelText24,
	NULL,
	NULL,
	levelText25,
	NULL,
	NULL,
	NULL,
	NULL,
};

const uint8_t levelTextsUpperSize[] = {
	sizeof(levelText00),
	sizeof(levelText01),
	0,
	0,
	sizeof(levelText02),
	0,
	0,
	0,
	0,
	0,
	0,
	sizeof(levelText03),
	sizeof(levelText04),
	0,
	0,
	sizeof(levelText05),
	sizeof(levelText06),
	sizeof(levelText03),
	sizeof(levelText07),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	sizeof(levelText08),
	sizeof(levelText09),
	0,
	sizeof(levelText09),
	0,
	sizeof(levelText0A),
	sizeof(levelText0B),
	sizeof(levelText0C),
	0,
	0,
	sizeof(levelText0D),
	sizeof(levelText0E),
	0,
	0,
	0,
	sizeof(levelText0F),
	sizeof(levelText10),
	0,
	0,
	0,
	0,
	sizeof(levelText11),
	0,
	sizeof(levelText12),
	0,
	0,
	sizeof(levelText13),
	0,
	sizeof(levelText14),
	sizeof(levelText12),
	0,
	sizeof(levelText15),
	sizeof(levelText16),
	0,
	sizeof(levelText17),
	sizeof(levelText18),
	sizeof(levelText19),
	0,
	sizeof(levelText1A),
	sizeof(levelText1B),
	0,
	0,
	0,
	0,
	0,
	sizeof(levelText1C),
	sizeof(levelText1D),
	0,
	0,
	0,
	0,
	0,
	sizeof(levelText1E),
	sizeof(levelText1F),
	sizeof(levelText20),
	0,
	0,
	0,
	sizeof(levelText21),
	0,
	0,
	sizeof(levelText22),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	sizeof(levelText23),
	0,
	0,
	0,
	0,
	sizeof(levelText24),
	0,
	0,
	sizeof(levelText25),
	0,
	0,
	0,
	0,
};


const char* const levelTextsLower[] = {
	levelText26,
	levelText27,
	levelText28,
	levelText29,
	levelText2A,
	levelText2B,
	levelText2C,
	levelText2D,
	levelText2E,
	levelText2F,
	levelText30,
	levelText31,
	levelText32,
	levelText33,
	levelText34,
	levelText35,
	levelText36,
	levelText37,
	levelText38,
	levelText39,
	levelText3A,
	levelText3B,
	levelText3C,
	levelText3D,
	levelText3E,
	levelText3F,
	levelText40,
	levelText41,
	levelText42,
	levelText43,
	levelText44,
	levelText45,
	levelText46,
	levelText47,
	levelText48,
	levelText49,
	levelText4A,
	levelText4B,
	levelText4C,
	levelText4D,
	levelText4E,
	levelText4F,
	levelText50,
	levelText51,
	levelText52,
	levelText53,
	levelText54,
	levelText55,
	levelText56,
	levelText57,
	levelText58,
	levelText59,
	levelText5A,
	levelText5B,
	levelText5C,
	levelText5D,
	levelText5E,
	levelText5F,
	levelText60,
	levelText61,
	levelText62,
	levelText63,
	levelText64,
	levelText65,
	levelText66,
	levelText67,
	levelText68,
	levelText69,
	levelText6A,
	levelText6B,
	levelText6C,
	levelText6D,
	levelText6E,
	levelText6F,
	levelText70,
	levelText71,
	levelText72,
	levelText73,
	levelText74,
	levelText26,
	levelText75,
	levelText76,
	levelText77,
	levelText78,
	levelText79,
	levelText7A,
	levelText7B,
	levelText33,
	levelText7C,
	levelText7D,
	levelText7E,
	levelText7F,
	levelText80,
	levelText81,
	levelText82,
	levelText83,
	levelText84,
	levelText85,
	levelText86,
	levelText14,
	levelText87,
	levelText88,
	levelText33,
	levelText89,
	levelText8A,
	levelText8B,
	levelText8C,
	levelText8D,
	levelText8E,
	levelText8F,
};

const uint8_t levelTextsLowerSize[] = {
	sizeof(levelText26),
	sizeof(levelText27),
	sizeof(levelText28),
	sizeof(levelText29),
	sizeof(levelText2A),
	sizeof(levelText2B),
	sizeof(levelText2C),
	sizeof(levelText2D),
	sizeof(levelText2E),
	sizeof(levelText2F),
	sizeof(levelText30),
	sizeof(levelText31),
	sizeof(levelText32),
	sizeof(levelText33),
	sizeof(levelText34),
	sizeof(levelText35),
	sizeof(levelText36),
	sizeof(levelText37),
	sizeof(levelText38),
	sizeof(levelText39),
	sizeof(levelText3A),
	sizeof(levelText3B),
	sizeof(levelText3C),
	sizeof(levelText3D),
	sizeof(levelText3E),
	sizeof(levelText3F),
	sizeof(levelText40),
	sizeof(levelText41),
	sizeof(levelText42),
	sizeof(levelText43),
	sizeof(levelText44),
	sizeof(levelText45),
	sizeof(levelText46),
	sizeof(levelText47),
	sizeof(levelText48),
	sizeof(levelText49),
	sizeof(levelText4A),
	sizeof(levelText4B),
	sizeof(levelText4C),
	sizeof(levelText4D),
	sizeof(levelText4E),
	sizeof(levelText4F),
	sizeof(levelText50),
	sizeof(levelText51),
	sizeof(levelText52),
	sizeof(levelText53),
	sizeof(levelText54),
	sizeof(levelText55),
	sizeof(levelText56),
	sizeof(levelText57),
	sizeof(levelText58),
	sizeof(levelText59),
	sizeof(levelText5A),
	sizeof(levelText5B),
	sizeof(levelText5C),
	sizeof(levelText5D),
	sizeof(levelText5E),
	sizeof(levelText5F),
	sizeof(levelText60),
	sizeof(levelText61),
	sizeof(levelText62),
	sizeof(levelText63),
	sizeof(levelText64),
	sizeof(levelText65),
	sizeof(levelText66),
	sizeof(levelText67),
	sizeof(levelText68),
	sizeof(levelText69),
	sizeof(levelText6A),
	sizeof(levelText6B),
	sizeof(levelText6C),
	sizeof(levelText6D),
	sizeof(levelText6E),
	sizeof(levelText6F),
	sizeof(levelText70),
	sizeof(levelText71),
	sizeof(levelText72),
	sizeof(levelText73),
	sizeof(levelText74),
	sizeof(levelText26),
	sizeof(levelText75),
	sizeof(levelText76),
	sizeof(levelText77),
	sizeof(levelText78),
	sizeof(levelText79),
	sizeof(levelText7A),
	sizeof(levelText7B),
	sizeof(levelText33),
	sizeof(levelText7C),
	sizeof(levelText7D),
	sizeof(levelText7E),
	sizeof(levelText7F),
	sizeof(levelText80),
	sizeof(levelText81),
	sizeof(levelText82),
	sizeof(levelText83),
	sizeof(levelText84),
	sizeof(levelText85),
	sizeof(levelText86),
	sizeof(levelText14),
	sizeof(levelText87),
	sizeof(levelText88),
	sizeof(levelText33),
	sizeof(levelText89),
	sizeof(levelText8A),
	sizeof(levelText8B),
	sizeof(levelText8C),
	sizeof(levelText8D),
	sizeof(levelText8E),
	sizeof(levelText8F),
};
