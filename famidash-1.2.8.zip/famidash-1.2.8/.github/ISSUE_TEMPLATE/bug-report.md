---
name: Bug Report
about: Report any bugs you may find in Famidash.
title: ''
labels: ''
assignees: ''

---

**Describe the bug**


**How to reproduce**


**Screenshots e/o videos**


**Emulator(please complete the following information):**
 - Device: [e.g. PC, Phone]:
 - Emulator [e.g. RetroArch, Mesen]:
 - Core [ONLY if you use RetroArch]:
