---
name: Feature Request
about: Suggest an idea for Famidash
title: ''
labels: ''
assignees: ''

---

**Your idea...**
