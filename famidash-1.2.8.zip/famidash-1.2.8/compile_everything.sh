rm -f TMP/*.*
cd MUSIC
./export.sh
cd ..
./LEVELS/export_levels.sh
make