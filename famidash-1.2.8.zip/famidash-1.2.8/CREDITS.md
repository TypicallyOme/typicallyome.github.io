# music credits
|Artist|Track|Additional Remarks|
|---|---|---|
|ForeverBound|Stereo Madness	||
|DJVI|Back On Track||
|Step|Polargeist||
|DJVI|Dry Out||
|DJVI|Base After Base||
|DJVI|Can't Let Go|	Known as "Cant Let Go" in game|
|Waterflame|Castle Crashers|Used in the level "Jumper"|
|Waterflame|Time Machine||
|DJVI|Cycles||
|DJVI|xStep||
|Waterflame|Clutterfunk||
|Dj-Nate|	Theory of Everything||
|OcularNebula|Stay Inside Me|Uses the edited version found in Geometry Dash during Practice Mode|